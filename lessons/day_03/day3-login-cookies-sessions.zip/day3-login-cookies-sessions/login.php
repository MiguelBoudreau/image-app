<?php 
require('config.php'); 
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Log In to your Account</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/milligram/1.4.1/milligram.min.css" integrity="sha512-xiunq9hpKsIcz42zt0o2vCo34xV0j6Ny8hgEylN3XBglZDtTZ2nwnqF/Z/TTCc18sGdvCjbFInNd++6q3J0N6g==" crossorigin="anonymous" />
	<style type="text/css">
		.login{
			max-width:30em;
		}
	</style>
</head>
<body>
	
	<div class="container login">
		<h1>Log in</h1>
		<form>
			<label>Username</label>
			<input type="text" name="">

			<label>Password</label>
			<input type="password" name="">

			<input type="submit" value="Log In">
		</form>
	</div>

</body>
</html>